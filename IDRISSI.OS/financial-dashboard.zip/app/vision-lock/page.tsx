import { redirect } from "next/navigation"

export default function VisionLockPage() {
  // Redirect to the principles page by default
  redirect("/vision-lock/principles")
}
